# CacheOnWheels
A plugin for the CFWheels Framework that allows multiple caching options with limited configuration necessary
